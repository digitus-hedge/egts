@extends('admin.layout')
@section('title', 'About Us Section')
@section('content')


<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.jsdelivr.net/npm/tinymce@6/tinymce.min.js" referrerpolicy="origin"></script>

@if ($errors->any())
    <div class="alert alert-error">
        <i class="bi bi-exclamation-circle"></i>
        <div>
            Please fill below fields before submitting:
            <!-- <ul style="margin: 6px 0 0 18px;">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul> -->
        </div>
    </div>
@endif

@if (session('success'))
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            Swal.fire({
                icon: 'success',
                title: 'Saved!',
                text: @json(session('success')),
                confirmButtonColor: '#3b3b58',
                timer: 2500,
                timerProgressBar: true
            });
        });
    </script>
@endif

<div class="form-header">
    <h4>
        <i class="bi bi-star"></i>
        About Us Section
    </h4>
</div>

<form action="{{ route('admin.about.store') }}" method="POST" enctype="multipart/form-data" class="banner-form" id="aboutForm">    @csrf

    <div class="container-fluid px-0">
        <div class="row">

            {{-- 1. BANNER SECTION --}}
            <div class="col-md-12">
                <div class="form-card">
                    <label class="section-label"><i class="bi bi-image"></i> Banner Section</label>

                    <div class="form-group">
                        <label>Heading <span class="text-danger">*</span></label>
                        <input type="text" name="banner_heading" value="{{ old('banner_heading', $about->banner_heading) }}"
                               class="{{ $errors->has('banner_heading') ? 'input-error' : '' }}">
                        @error('banner_heading')<span class="field-error">{{ $message }}</span>@enderror
                    </div>

                    <div class="form-group" style="margin-top:14px;">
                        <label>Description <span class="text-danger">*</span></label>
                        <textarea name="banner_description" class="rich-text {{ $errors->has('banner_description') ? 'input-error' : '' }}">{{ old('banner_description', $about->banner_description) }}</textarea>
                        @error('banner_description')<span class="field-error">{{ $message }}</span>@enderror
                    </div>

                    <div class="form-group" style="margin-top:14px;">
                        <label>Banner Image</label>
                        <p class="hint-text">Max 2MB — JPG, PNG, WEBP</p>
                        <div class="image-upload-box">
                            <div class="preview-wrap">
                                @if ($about->banner_image)
                                    <img src="{{ Storage::url($about->banner_image) }}" class="preview-img" id="preview-banner">
                                @else
                                    <div class="preview-placeholder" id="preview-banner"><i class="bi bi-image"></i></div>
                                @endif
                            </div>
                            <label class="upload-btn">
                                <i class="bi bi-upload"></i> Choose file
                                <input type="file" name="banner_image" accept="image/*" onchange="previewImage(this,'preview-banner')" hidden>
                            </label>
                            @error('banner_image')<span class="field-error d-block mt-2">{{ $message }}</span>@enderror
                        </div>
                    </div>
                </div>
            </div>

            {{-- 2. SECTION TWO --}}
            <div class="col-md-12">
                <div class="form-card">
                    <label class="section-label"><i class="bi bi-layout-text-window"></i> Section Two</label>

                    <div class="form-group">
                        <label>Heading <span class="text-danger">*</span></label>
                        <input type="text" name="section_two_heading" value="{{ old('section_two_heading', $about->section_two_heading) }}"
                               class="{{ $errors->has('section_two_heading') ? 'input-error' : '' }}">
                        @error('section_two_heading')<span class="field-error">{{ $message }}</span>@enderror
                    </div>

                    <div class="form-group" style="margin-top:14px;">
                        <label>Description <span class="text-danger">*</span></label>
                        <textarea name="section_two_description" class="rich-text {{ $errors->has('section_two_description') ? 'input-error' : '' }}">{{ old('section_two_description', $about->section_two_description) }}</textarea>
                        @error('section_two_description')<span class="field-error">{{ $message }}</span>@enderror
                    </div>

                    <div class="row" style="margin-top:14px;">
                        @foreach (['image_one' => 'Image One', 'image_two' => 'Image Two'] as $suffix => $label)
                            @php $field = 'section_two_' . $suffix; @endphp
                            <div class="col-md-6">
                                <label>{{ $label }}</label>
                                <div class="image-upload-box">
                                    <div class="preview-wrap">
                                        @if ($about->{$field})
                                            <img src="{{ Storage::url($about->{$field}) }}" class="preview-img" id="preview-{{ $field }}">
                                        @else
                                            <div class="preview-placeholder" id="preview-{{ $field }}"><i class="bi bi-image"></i></div>
                                        @endif
                                    </div>
                                    <label class="upload-btn">
                                        <i class="bi bi-upload"></i> Choose file
                                        <input type="file" name="{{ $field }}" accept="image/*" onchange="previewImage(this,'preview-{{ $field }}')" hidden>
                                    </label>
                                    @error($field)<span class="field-error d-block mt-2">{{ $message }}</span>@enderror
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>

            {{-- 3. VISION + 4. MISSION --}}
            @foreach (['vision' => ['Vision', 'bi-eye'], 'mission' => ['Mission', 'bi-bullseye']] as $key => [$label, $icon])
                <div class="col-md-6">
                    <div class="form-card">
                        <label class="section-label"><i class="bi {{ $icon }}"></i> {{ $label }}</label>

                        <div class="form-group">
                            <label>Heading <span class="text-danger">*</span></label>
                            <input type="text" name="{{ $key }}_heading" value="{{ old($key.'_heading', $about->{$key.'_heading'}) }}"
                                   class="{{ $errors->has($key.'_heading') ? 'input-error' : '' }}">
                            @error($key.'_heading')<span class="field-error">{{ $message }}</span>@enderror
                        </div>

                        <div class="form-group" style="margin-top:14px;">
                            <label>Description <span class="text-danger">*</span></label>
                            <textarea name="{{ $key }}_description" class="rich-text {{ $errors->has($key.'_description') ? 'input-error' : '' }}">{{ old($key.'_description', $about->{$key.'_description'}) }}</textarea>
                            @error($key.'_description')<span class="field-error">{{ $message }}</span>@enderror
                        </div>

                        <div class="form-group" style="margin-top:14px;">
                            <label>{{ $label }} Image</label>
                            <div class="image-upload-box">
                                <div class="preview-wrap">
                                    @if ($about->{$key.'_image'})
                                        <img src="{{ Storage::url($about->{$key.'_image'}) }}" class="preview-img" id="preview-{{ $key }}">
                                    @else
                                        <div class="preview-placeholder" id="preview-{{ $key }}"><i class="bi bi-image"></i></div>
                                    @endif
                                </div>
                                <label class="upload-btn">
                                    <i class="bi bi-upload"></i> Choose file
                                    <input type="file" name="{{ $key }}_image" accept="image/*" onchange="previewImage(this,'preview-{{ $key }}')" hidden>
                                </label>
                                @error($key.'_image')<span class="field-error d-block mt-2">{{ $message }}</span>@enderror
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach

            {{-- 5. OUR FOUNDATION (intro) --}}
            <div class="col-md-12">
                <div class="form-card">
                    <label class="section-label"><i class="bi bi-bank"></i> Our Foundation</label>

                    <div class="form-group">
                        <label>Heading <span class="text-danger">*</span></label>
                        <input type="text" name="foundation_heading" value="{{ old('foundation_heading', $about->foundation_heading) }}"
                               class="{{ $errors->has('foundation_heading') ? 'input-error' : '' }}">
                        @error('foundation_heading')<span class="field-error">{{ $message }}</span>@enderror
                    </div>

                    <div class="form-group" style="margin-top:14px;">
                        <label>Description <span class="text-danger">*</span></label>
                        <textarea name="foundation_description" class="rich-text {{ $errors->has('foundation_description') ? 'input-error' : '' }}">{{ old('foundation_description', $about->foundation_description) }}</textarea>
                        @error('foundation_description')<span class="field-error">{{ $message }}</span>@enderror
                    </div>
                </div>
            </div>

            {{-- 6. FOUNDATION LIST (repeater) --}}
         {{-- 6. FOUNDATION LIST (fixed: 2 items) --}}
<div class="col-md-12">
    <div class="form-card">
        <label class="section-label"><i class="bi bi-list-ul"></i> Foundation List</label>

        <div class="row">
            @foreach ([1 => 'Item One', 2 => 'Item Two'] as $num => $label)
                @php
                    $hKey = "foundation_item_{$num}_heading" === "foundation_item_1_heading" ? 'foundation_item_one_heading' : 'foundation_item_two_heading';
                @endphp
            @endforeach

            {{-- Item One --}}
            <div class="col-md-6">
                <div class="foundation-item-block">
                    <label class="section-label" style="font-size:13px;">Item One</label>

                    <div class="form-group">
                        <label>Heading <span class="text-danger">*</span></label>
                        <input type="text" name="foundation_item_one_heading"
                               value="{{ old('foundation_item_one_heading', $about->foundation_item_one_heading) }}"
                               class="{{ $errors->has('foundation_item_one_heading') ? 'input-error' : '' }}">
                        @error('foundation_item_one_heading')<span class="field-error">{{ $message }}</span>@enderror
                    </div>

                    <div class="form-group" style="margin-top:12px;">
                        <label>Description <span class="text-danger">*</span></label>
                        <textarea name="foundation_item_one_description" class="rich-text {{ $errors->has('foundation_item_one_description') ? 'input-error' : '' }}">{{ old('foundation_item_one_description', $about->foundation_item_one_description) }}</textarea>
                        @error('foundation_item_one_description')<span class="field-error">{{ $message }}</span>@enderror
                    </div>

                    <div class="form-group" style="margin-top:12px;">
                        <label>Image</label>
                        <div class="image-upload-box">
                            <div class="preview-wrap">
                                @if ($about->foundation_item_one_image)
                                    <img src="{{ Storage::url($about->foundation_item_one_image) }}" class="preview-img" id="preview-foundation-one">
                                @else
                                    <div class="preview-placeholder" id="preview-foundation-one"><i class="bi bi-image"></i></div>
                                @endif
                            </div>
                            <label class="upload-btn">
                                <i class="bi bi-upload"></i> Choose file
                                <input type="file" name="foundation_item_one_image" accept="image/*" onchange="previewImage(this,'preview-foundation-one')" hidden>
                            </label>
                            @error('foundation_item_one_image')<span class="field-error d-block mt-2">{{ $message }}</span>@enderror
                        </div>
                    </div>
                </div>
            </div>

            {{-- Item Two --}}
            <div class="col-md-6">
                <div class="foundation-item-block">
                    <label class="section-label" style="font-size:13px;">Item Two</label>

                    <div class="form-group">
                        <label>Heading <span class="text-danger">*</span></label>
                        <input type="text" name="foundation_item_two_heading"
                               value="{{ old('foundation_item_two_heading', $about->foundation_item_two_heading) }}"
                               class="{{ $errors->has('foundation_item_two_heading') ? 'input-error' : '' }}">
                        @error('foundation_item_two_heading')<span class="field-error">{{ $message }}</span>@enderror
                    </div>

                    <div class="form-group" style="margin-top:12px;">
                        <label>Description <span class="text-danger">*</span></label>
                        <textarea name="foundation_item_two_description" class="rich-text {{ $errors->has('foundation_item_two_description') ? 'input-error' : '' }}">{{ old('foundation_item_two_description', $about->foundation_item_two_description) }}</textarea>
                        @error('foundation_item_two_description')<span class="field-error">{{ $message }}</span>@enderror
                    </div>

                    <div class="form-group" style="margin-top:12px;">
                        <label>Image</label>
                        <div class="image-upload-box">
                            <div class="preview-wrap">
                                @if ($about->foundation_item_two_image)
                                    <img src="{{ Storage::url($about->foundation_item_two_image) }}" class="preview-img" id="preview-foundation-two">
                                @else
                                    <div class="preview-placeholder" id="preview-foundation-two"><i class="bi bi-image"></i></div>
                                @endif
                            </div>
                            <label class="upload-btn">
                                <i class="bi bi-upload"></i> Choose file
                                <input type="file" name="foundation_item_two_image" accept="image/*" onchange="previewImage(this,'preview-foundation-two')" hidden>
                            </label>
                            @error('foundation_item_two_image')<span class="field-error d-block mt-2">{{ $message }}</span>@enderror
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

            <div class="col-md-12">
                <div class="form-actions">
                    <a href="{{ route('admin.dashboard') }}" class="btn-cancel">Cancel</a>
                    <button type="submit" class="btn-submit"><i class="bi bi-check-lg"></i> Save</button>
                </div>
            </div>

        </div>
    </div>
</form>

<script>
    function previewImage(input, previewId) {
        const preview = document.getElementById(previewId);
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = function (e) {
                if (preview.tagName === 'IMG') {
                    preview.src = e.target.result;
                } else {
                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.className = 'preview-img';
                    img.id = previewId;
                    preview.replaceWith(img);
                }
            };
            reader.readAsDataURL(input.files[0]);
        }
    }

        function initRichText(selector) {
        tinymce.init({
            selector: selector,
            height: 250,
            menubar: false,
            plugins: 'lists link image code table',
            toolbar: 'undo redo | bold italic | bullist numlist | link | code',
            branding: false,
            promotion: false,
            setup: function (editor) {
                editor.on('change', function () { editor.save(); });
            }
        });
    }

    document.addEventListener('DOMContentLoaded', function () {
        initRichText('.rich-text');
    });
</script>

<style>
    .alert { padding: 12px 16px; border-radius: 6px; margin-bottom: 20px; font-size: 14px; display:flex; align-items:center; gap:8px; }
    .alert-error { background: #fdecea; color: #c0392b; }
    .form-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 22px; }
    .form-header h4 { display: flex; align-items: center; gap: 8px; color: #1e1e2d; }
    .banner-form { width: 100%; }
    .form-card { background: #fff; padding: 22px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.08); margin-bottom: 18px; height: calc(100% - 18px); }
    .form-group label { display: block; margin-bottom: 7px; font-weight: 600; font-size: 13px; color: #333; }
    .form-group input[type="text"], .form-group textarea { width: 100%; padding: 10px 12px; border: 1px solid #ddd; border-radius: 6px; font-size: 14px; outline: none; font-family: inherit; resize: vertical; }
    .form-group input:focus, .form-group textarea:focus { border-color: #3b3b58; }
    .section-label { display: flex; align-items: center; gap: 6px; font-weight: 700; font-size: 15px; color: #1e1e2d; margin-bottom: 14px; }
    .hint-text { font-size: 12px; color: #888; margin: 4px 0 10px; }
    .input-error { border-color: #e74c3c !important; background: #fff8f8; }
    .field-error { display: flex; align-items: center; gap: 5px; color: #e74c3c; font-size: 12.5px; margin-top: 6px; }

    .block-card { border-top: 3px solid #b40707; }
    .commitment-card { border-top: 3px solid #3b3b58; }

    .image-upload-box { display: flex; flex-direction: column; align-items: flex-start; }
    .preview-wrap { width: 100%; }
    .preview-img { width: 100%; height: 140px; object-fit: cover; border-radius: 6px; border: 1px solid #eee; margin-bottom: 10px; }
    .preview-placeholder { width: 100%; height: 140px; display: flex; align-items: center; justify-content: center; background: #f4f6f9; border-radius: 6px; border: 1px dashed #ddd; color: #bbb; font-size: 26px; margin-bottom: 10px; }
    .upload-btn { display: inline-flex; align-items: center; gap: 6px; background: #f4f6f9; color: #3b3b58; padding: 7px 14px; border-radius: 6px; font-size: 13px; cursor: pointer; border: 1px solid #ddd; }
    .upload-btn:hover { background: #e9ecf2; }

    .form-actions { display: flex; gap: 12px; margin-top: 6px; }
    .btn-cancel { padding: 11px 22px; border-radius: 6px; border: 1px solid #ddd; color: #555; text-decoration: none; font-size: 14px; }
    .btn-cancel:hover { background: #f4f6f9; }
    .btn-submit { display: flex; align-items: center; gap: 7px; background: #3b3b58; color: #fff; border: none; padding: 11px 24px; border-radius: 6px; font-size: 14px; font-weight: 600; cursor: pointer; }
    .btn-submit:hover { background: #2b2b42; }
</style>

@endsection
