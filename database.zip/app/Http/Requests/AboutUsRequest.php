// app/Http/Requests/AboutUsRequest.php
<?php

namespace App\Http\Requests;

use App\Models\AboutUs;
use Illuminate\Foundation\Http\FormRequest;

class AboutUsRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'banner_heading'          => 'required|string|max:255',
            'banner_description'      => 'required|string',
            'banner_image'            => 'nullable|image|mimes:jpeg,jpg,png,webp|max:2048',

            'section_two_heading'     => 'required|string|max:255',
            'section_two_description' => 'required|string',
            'section_two_image_one'   => 'nullable|image|mimes:jpeg,jpg,png,webp|max:2048',
            'section_two_image_two'   => 'nullable|image|mimes:jpeg,jpg,png,webp|max:2048',

            'vision_heading'          => 'required|string|max:255',
            'vision_description'      => 'required|string',
            'vision_image'            => 'nullable|image|mimes:jpeg,jpg,png,webp|max:2048',

            'mission_heading'         => 'required|string|max:255',
            'mission_description'     => 'required|string',
            'mission_image'           => 'nullable|image|mimes:jpeg,jpg,png,webp|max:2048',

            'foundation_heading'      => 'required|string|max:255',
            'foundation_description'  => 'required|string',

            'foundation_item_one_heading'     => 'required|string|max:255',
            'foundation_item_one_description' => 'required|string',
            'foundation_item_one_image'       => 'nullable|image|mimes:jpeg,jpg,png,webp|max:2048',

            'foundation_item_two_heading'     => 'required|string|max:255',
            'foundation_item_two_description' => 'required|string',
            'foundation_item_two_image'       => 'nullable|image|mimes:jpeg,jpg,png,webp|max:2048',
        ];
    }

    public function messages(): array
    {
        return [
            '*.required' => 'This field is required.',
        ];
    }

    public function withValidator($validator): void
    {
        $validator->after(function ($validator) {
            $about = AboutUs::first();

            $imageFields = [
                'banner_image',
                'section_two_image_one',
                'section_two_image_two',
                'vision_image',
                'mission_image',
                'foundation_item_one_image',
                'foundation_item_two_image',
            ];

            foreach ($imageFields as $field) {
                $hasNew = $this->hasFile($field);
                $hasExisting = $about && !empty($about->{$field});

                if (!$hasNew && !$hasExisting) {
                    $validator->errors()->add($field, 'Please upload an image for this section.');
                }
            }
        });
    }
}