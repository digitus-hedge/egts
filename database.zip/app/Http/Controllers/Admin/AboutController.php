// app/Http/Controllers/Admin/AboutController.php
<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\AboutUsRequest;
use App\Models\AboutUs;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;
use Intervention\Image\Format;

class AboutController extends Controller
{
    protected int $imageWidth = 1000;
    protected int $imageHeight = 700;
    protected int $compressQuality = 70;

    public function index()
    {
        $about = AboutUs::first() ?? new AboutUs();

        return view('admin.about.form', compact('about'));
    }

    public function store(AboutUsRequest $request)
    {
        $data = $request->validated();

        $about = AboutUs::first() ?? new AboutUs();

        $about->fill([
            'banner_heading'                   => $data['banner_heading'],
            'banner_description'               => $data['banner_description'],
            'section_two_heading'              => $data['section_two_heading'],
            'section_two_description'          => $data['section_two_description'],
            'vision_heading'                   => $data['vision_heading'],
            'vision_description'               => $data['vision_description'],
            'mission_heading'                  => $data['mission_heading'],
            'mission_description'              => $data['mission_description'],
            'foundation_heading'               => $data['foundation_heading'],
            'foundation_description'           => $data['foundation_description'],
            'foundation_item_one_heading'      => $data['foundation_item_one_heading'],
            'foundation_item_one_description'  => $data['foundation_item_one_description'],
            'foundation_item_two_heading'      => $data['foundation_item_two_heading'],
            'foundation_item_two_description'  => $data['foundation_item_two_description'],
        ]);

        $imageFields = [
            'banner_image',
            'section_two_image_one',
            'section_two_image_two',
            'vision_image',
            'mission_image',
            'foundation_item_one_image',
            'foundation_item_two_image',
        ];

        foreach ($imageFields as $field) {
            if ($request->hasFile($field)) {
                if ($about->{$field}) {
                    Storage::disk('public')->delete($about->{$field});
                }
                $about->{$field} = $this->processAndStoreImage($request->file($field));
            }
        }

        $about->save();

        return redirect()
            ->route('admin.home.about')
            ->with('success', 'About Us page saved successfully.');
    }

    private function processAndStoreImage($file): string
    {
        $filename = 'about-us/' . Str::random(20) . '.webp';

        $manager  = ImageManager::usingDriver(Driver::class);
        $image    = $manager->decode($file);
        $image->cover($this->imageWidth, $this->imageHeight);
        $encoded  = $image->encodeUsingFormat(Format::WEBP, quality: $this->compressQuality);

        Storage::disk('public')->put($filename, (string) $encoded);

        return $filename;
    }
}